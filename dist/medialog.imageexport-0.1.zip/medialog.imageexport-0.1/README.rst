Introduction
============

Adds a browser view to export all images from a folder as a zip file.

Use it like this:
http://mysite/myfolder/image-export?imagesize='pil_scale'

http://mysite/myfolder/image-export?imagesize=mini

http://mysite/myfolder/image-export?imagesize=thumb